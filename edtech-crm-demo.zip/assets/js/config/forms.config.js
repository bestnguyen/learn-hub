window.FORM_CONFIG = {
  leads:{title:"Lead",fields:[
    {name:"full_name",label:"Full name",type:"text",required:true,placeholder:"Enter full name"},
    {name:"contact_type",label:"Registrant type",type:"select",required:true,options:["Parent","Student"]},
    {name:"phone",label:"Phone number",type:"tel",required:true},
    {name:"email",label:"Email",type:"email"},
    {name:"school",label:"Current school",type:"text"},
    {name:"program",label:"Interested program",type:"select",options:["IB","A-Level","AP","General English"]},
    {name:"subjects",label:"Interested subjects",type:"multiselect",options:["Math","Computer Science","Physics","Biology","Chemistry","Business","Economics","Language Literature","English","Chinese","Spanish","French"]},
    {name:"status",label:"Lead status",type:"select",options:["New","Contacted","Consulting","Trial","Won","Lost"]},
    {name:"owner",label:"Sales owner",type:"text"},
    {name:"notes",label:"Notes",type:"textarea",full:true}
  ]},
  students:{title:"Learner",fields:[
    {name:"customer_id",label:"Family customer",type:"select-data",source:"customers",display:"family_name",required:true},
    {name:"full_name",label:"Learner full name",type:"text",required:true},
    {name:"grade",label:"Current grade",type:"select",options:["Grade 1","Grade 2","Grade 3","Grade 4","Grade 5","Grade 6","Grade 7","Grade 8","Grade 9","Grade 10","Grade 11","Grade 12"]},
    {name:"school",label:"Current school",type:"text"},
    {name:"program",label:"Program",type:"select",options:["IB","A-Level","AP","English","General"]},
    {name:"status",label:"Learning status",type:"select",options:["Active","On hold","Completed"]}
  ]},
  customers:{title:"Family customer",fields:[
    {name:"family_name",label:"Family name",type:"text",required:true},
    {name:"primary_contact",label:"Primary contact",type:"text",required:true},
    {name:"phone",label:"Phone",type:"tel",required:true},
    {name:"email",label:"Email",type:"email"},
    {name:"address",label:"Address",type:"text"},
    {name:"source_lead",label:"Source lead",type:"select-data",source:"leads",display:"full_name"}
  ]},
  contracts:{title:"Contract",fields:[
    {name:"customer_id",label:"Family customer",type:"select-data",source:"customers",display:"family_name",required:true},
    {name:"date",label:"Contract date",type:"date",required:true},
    {name:"value",label:"Contract value (VND)",type:"number",required:true},
    {name:"status",label:"Contract status",type:"select",options:["Draft","Pending signature","Active","Completed","Cancelled"]},
    {name:"notes",label:"Notes",type:"textarea",full:true}
  ]},
  classes:{title:"Class",fields:[
    {name:"name",label:"Class name",type:"text",required:true},
    {name:"subject",label:"Subject",type:"select",options:["Math","Computer Science","Physics","Biology","Chemistry","English","Chinese","Spanish","French"]},
    {name:"program",label:"Program",type:"select",options:["IB","A-Level","AP","General"]},
    {name:"mode",label:"Learning mode",type:"select",options:["Group","1-on-1"]},
    {name:"teacher",label:"Teacher",type:"text"},
    {name:"capacity",label:"Maximum learners",type:"number"},
    {name:"status",label:"Status",type:"select",options:["Active","Inactive"]}
  ]},
  schedules:{title:"Schedule",fields:[
    {name:"class_id",label:"Class",type:"select-data",source:"classes",display:"name",required:true},
    {name:"day",label:"Day of week",type:"select",options:["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"],required:true},
    {name:"start",label:"Start time",type:"time",required:true},
    {name:"end",label:"End time",type:"time",required:true},
    {name:"room",label:"Room / meeting link",type:"text"},
    {name:"start_date",label:"Effective date",type:"date"}
  ]},
  enrollments:{title:"Enrollment",fields:[
    {name:"contract_id",label:"Contract",type:"select-data",source:"contracts",display:"id",required:true},
    {name:"student_id",label:"Learner",type:"select-data",source:"students",display:"full_name",required:true},
    {name:"course",label:"Course / subject",type:"text",required:true},
    {name:"mode",label:"Learning mode",type:"select",options:["1-on-1","Group"],required:true},
    {name:"sessions",label:"Number of sessions",type:"number"},
    {name:"class_id",label:"Assigned class",type:"select-data",source:"classes",display:"name"},
    {name:"status",label:"Enrollment status",type:"select",options:["Pending","Active","Completed","On hold"]}
  ]}
};
