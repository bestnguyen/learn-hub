window.Store = {
  key:"edtech_crm_demo_v1",
  data:null,
  init(){try{this.data=JSON.parse(localStorage.getItem(this.key))||structuredClone(window.DEMO_SEED)}catch(e){this.data=JSON.parse(JSON.stringify(window.DEMO_SEED))}this.save()},
  save(){localStorage.setItem(this.key,JSON.stringify(this.data))},
  reset(){this.data=JSON.parse(JSON.stringify(window.DEMO_SEED));this.save()},
  list(entity){return this.data[entity]||[]},
  add(entity,record){const prefix={leads:"LD",customers:"CUS",students:"ST",contracts:"CT",classes:"CL",schedules:"SC",enrollments:"EN"}[entity]||"ID";const next=this.list(entity).length+1;record.id=record.id||`${prefix}-${String(Date.now()).slice(-5)}${next}`;this.data[entity].unshift(record);this.save();return record},
  update(entity,id,record){const arr=this.list(entity);const i=arr.findIndex(x=>x.id===id);if(i>=0){arr[i]={...arr[i],...record};this.save();return arr[i]}return null},
  remove(entity,id){this.data[entity]=this.list(entity).filter(x=>x.id!==id);this.save()}
};
