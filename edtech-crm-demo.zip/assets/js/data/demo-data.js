window.DEMO_SEED = {
  leads: [
    {id:"LD-1001",full_name:"Nguyen Van An",contact_type:"Parent",phone:"0901 234 567",email:"an.nguyen@example.com",school:"Vinschool",program:"IB",subjects:["Math","Physics"],status:"Consulting",owner:"Linh Tran",created_at:"2026-11-01",notes:"Interested in IB support for two children."},
    {id:"LD-1002",full_name:"Tran Minh Chau",contact_type:"Student",phone:"0902 111 222",email:"chau.tran@example.com",school:"BIS",program:"A-Level",subjects:["Chemistry","Biology"],status:"New",owner:"Minh Le",created_at:"2026-11-03",notes:"Prefers weekend classes."},
    {id:"LD-1003",full_name:"Le Thu Ha",contact_type:"Parent",phone:"0903 333 444",email:"ha.le@example.com",school:"ISPH",program:"AP",subjects:["Computer Science","Math"],status:"Trial",owner:"Linh Tran",created_at:"2026-10-29",notes:"Trial class requested."},
    {id:"LD-1004",full_name:"Pham Quoc Bao",contact_type:"Student",phone:"0904 555 666",email:"bao.pham@example.com",school:"Hanoi-Amsterdam",program:"IB",subjects:["English"],status:"Won",owner:"Minh Le",created_at:"2026-10-25",notes:"Converted to customer."}
  ],
  customers:[{id:"CUS-001",family_name:"Nguyen Family",primary_contact:"Nguyen Van An",phone:"0901 234 567",email:"an.nguyen@example.com",address:"Cau Giay, Hanoi",source_lead:"LD-1001"}],
  students:[
    {id:"ST-001",customer_id:"CUS-001",full_name:"Nguyen Minh Anh",grade:"Grade 10",school:"Vinschool",program:"IB",status:"Active"},
    {id:"ST-002",customer_id:"CUS-001",full_name:"Nguyen Minh Khang",grade:"Grade 7",school:"Vinschool",program:"English",status:"Active"}
  ],
  contracts:[
    {id:"CT-001",customer_id:"CUS-001",date:"2026-11-02",status:"Active",value:42000000,notes:"Family learning package"}
  ],
  enrollments:[
    {id:"EN-001",contract_id:"CT-001",student_id:"ST-001",course:"IB Math",mode:"1-on-1",sessions:20,class_id:"CL-002",status:"Active"},
    {id:"EN-002",contract_id:"CT-001",student_id:"ST-001",course:"IB Physics",mode:"Group",sessions:12,class_id:"CL-001",status:"Active"},
    {id:"EN-003",contract_id:"CT-001",student_id:"ST-002",course:"English",mode:"Group",sessions:16,class_id:"CL-003",status:"Active"}
  ],
  classes:[
    {id:"CL-001",name:"IB Physics G1",subject:"Physics",program:"IB",mode:"Group",teacher:"David Nguyen",capacity:10,status:"Active"},
    {id:"CL-002",name:"IB Math 1-on-1",subject:"Math",program:"IB",mode:"1-on-1",teacher:"Sarah Pham",capacity:1,status:"Active"},
    {id:"CL-003",name:"English G7",subject:"English",program:"General",mode:"Group",teacher:"Mai Hoang",capacity:8,status:"Active"}
  ],
  schedules:[
    {id:"SC-001",class_id:"CL-001",day:"Tuesday",start:"17:00",end:"18:30",room:"Room 201",start_date:"2026-11-03"},
    {id:"SC-002",class_id:"CL-002",day:"Wednesday",start:"18:00",end:"19:00",room:"Online",start_date:"2026-11-04"},
    {id:"SC-003",class_id:"CL-003",day:"Saturday",start:"09:00",end:"10:30",room:"Room 105",start_date:"2026-11-07"}
  ],
  appointments:[{id:"AP-001",title:"Trial class – Le Thu Ha",date:"2026-11-06",time:"16:00",type:"Trial"}]
};
