# EdTech CRM Demo

A lightweight, browser-based SPA prototype for validating an EdTech CRM workflow with stakeholders.

## Run locally
1. Extract the ZIP file.
2. Open `index.html` in Chrome, Edge or Firefox.
3. Internet access is required for Bootstrap and Bootstrap Icons CDN assets.

If your browser blocks local scripts, run a simple local server from this folder:
- Python: `python -m http.server 8000`
- Open `http://localhost:8000`

## Included modules
- Dashboard
- Lead Management
- Customers & Students
- Contracts
- Enrollments
- Classes
- Schedules
- Calendar
- Reports

## Edit fields quickly
Edit `assets/js/config/forms.config.js`. Each entity defines its fields, labels, input types, dropdown options and required flags. The shared renderer in `assets/js/modules/renderers.js` renders the forms.

Supported field types:
- `text`, `tel`, `email`, `number`, `date`, `time`
- `textarea`
- `select`
- `multiselect`
- `select-data` (dropdown populated from another entity)

## Data and limitations
- Sample data: `assets/js/data/demo-data.js`
- Persistence: browser LocalStorage
- Reset: use **Reset demo data** in the sidebar
- This is a workflow prototype, not a production CRM.
- No authentication, payment processing, server-side validation, audit trail, or multi-user sync.
- Calendar currently displays recurring weekly schedules.
- Lead status `Won` automatically creates a family customer record if one does not already exist. Learner profiles can then be added from Customers & Students.
